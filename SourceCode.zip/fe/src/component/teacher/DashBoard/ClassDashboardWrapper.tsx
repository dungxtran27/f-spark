import ClassListWrapper from "../ClassList";

const ClassDashboardWrapper = () => {
  return (
    <div className="">
      <ClassListWrapper />
    </div>
  );
};
export default ClassDashboardWrapper;
