const Outcome = () => {
    return (
       <div>abc</div>
    );
   }
   
   export default Outcome;