const Report = () =>{
    return (
        <span>report tab</span>
    )
}
export default Report;