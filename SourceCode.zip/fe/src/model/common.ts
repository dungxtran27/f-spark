export interface ModalProps {
  isOpen: boolean;
  setIsOpen: (value: boolean) => void;
}
