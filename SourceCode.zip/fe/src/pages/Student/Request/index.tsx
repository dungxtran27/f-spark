import DefaultLayout from "../../../layout/DefaultLayout";
import RequestWrapper from "../../../component/student/Request";
const Requests = () => {
  return (
    <DefaultLayout>
      <RequestWrapper />
    </DefaultLayout>
  );
};
export default Requests;
