import DefaultLayout from "../../../layout/DefaultLayout";
import TaskWrapper from "../../../component/student/Tasks";
const Tasks = () => {
  return (
    <DefaultLayout>
      <TaskWrapper />
    </DefaultLayout>
  );
};
export default Tasks;
