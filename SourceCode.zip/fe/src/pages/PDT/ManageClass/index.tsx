import DefaultLayout from "../../../layout/DefaultLayout";
import ManageClassWrapper from "../../../component/pdt/ManageClass/index";
const ManageClass = () => {
  return (
    <DefaultLayout>
      <ManageClassWrapper />
    </DefaultLayout>
  );
};
export default ManageClass;
