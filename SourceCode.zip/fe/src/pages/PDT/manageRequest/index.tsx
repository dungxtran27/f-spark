import DefaultLayout from "../../../layout/DefaultLayout";
import RequestWrapper from "../../../component/pdt/ManageRequest";
const ManageRequest = () => {
  return (
    <DefaultLayout>
      <RequestWrapper />
    </DefaultLayout>
  );
};
export default ManageRequest;
