import DefaultLayout from "../../../layout/DefaultLayout";
import TermWrapper from "../../../component/pdt/ManageTerm";
const ManageTerm = () => {
  return (
    <DefaultLayout>
      <TermWrapper />
    </DefaultLayout>
  );
};
export default ManageTerm;
