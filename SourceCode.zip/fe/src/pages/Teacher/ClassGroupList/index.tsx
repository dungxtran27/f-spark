import ClassGroupListWrapper from "./ClassGroupListWrapper";

const ClassGroupList = () => {
  return <ClassGroupListWrapper />;
};
export default ClassGroupList;
