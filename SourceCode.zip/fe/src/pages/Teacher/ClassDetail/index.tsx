import ClassDetailWrapper from "../../../component/teacher/ClassDetail";

const ClassDetail = () => {
  return <ClassDetailWrapper />;
};
export default ClassDetail;
