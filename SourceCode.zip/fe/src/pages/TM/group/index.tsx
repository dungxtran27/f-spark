import DefaultLayout from "../../../layout/DefaultLayout";
import ClassesStatisticWrapper from "./classesStatisticWrapper";
// import ManageClassWrapper from "../../../component/pdt/ManageClass/index";
const ManageClassTM = () => {
  return (
    <DefaultLayout>
      <ClassesStatisticWrapper/>
    </DefaultLayout>
  );
};
export default ManageClassTM;
