import DefaultLayout from "../../../layout/DefaultLayout";
import DashboardTMWrapper from "./dashboardTMWrapper";
// import ManageClassWrapper from "../../../component/pdt/ManageClass/index";
const DashboardTM = () => {
  return (
    <DefaultLayout>
      <DashboardTMWrapper/>
    </DefaultLayout>
  );
};
export default DashboardTM;
